// Multi-Colored Grid
// Mason L.
// Sept. 27 2023
//



let gridSpacing = 30;
let overlay;

function setup() {
  document.addEventListener("contextmenu", event => event.preventDefault());
  createCanvas(windowWidth, windowHeight);
  drawGrid();
}

function mousePressed() {
  if(mouseButton === LEFT){
    if(gridSpacing < 10){
      gridSpacing=5;
    }
    else{
      gridSpacing = gridSpacing - 5;
    }
  }
  if(mouseButton === RIGHT){
    gridSpacing = gridSpacing + 5;
  }
  drawGrid();
}


function drawGrid(){
  for (let x = 0; x < width; x = x + gridSpacing){
    for (let y = 0; y < height ; y = y + gridSpacing){
      square(x,y,gridSpacing);
      fill(random(0,255), random(0,255), random(0,255));
    }
  }
}


function draw(){
  if(keyIsPressed){
    drawGrid();
  }
  
  
}